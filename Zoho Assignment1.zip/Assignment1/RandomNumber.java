package Assignment1;

public class RandomNumber {

	public static void main(String[] args) {
		double d=Math.random();
	
		System.out.print(d);
	}

}
