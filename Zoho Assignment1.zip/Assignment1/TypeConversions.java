package Assignment1;

public class TypeConversions {
	public static void main(String[] args) {

		float a = 0.7f;
		int b = (int) a;
		System.out.println(b);

		double d = 1.8;
		float f = (float) d;
		System.out.println(f);

		int x = 8222;
		short y = (short) x;
		System.out.println(y);

	}

}
